package org.davyecris.hotel.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import org.antlr.v4.runtime.misc.NotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
public class Reserva {
    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    @Size(min = 3, max = 100)
    private String nomeHospede;

    @Column(nullable = false)
    @Email
    private String emailHospede;

    @Column(nullable = false)
    private LocalDate dataEntrada;

    @Column(nullable = false)
    private LocalDate dataSaida;

    private LocalDateTime dataCheckin;

    private LocalDateTime dataCheckout;

    private LocalDateTime dataCriacao;

    @Column(nullable = false)
    private TipoQuarto tipoQuarto;

    @Column(nullable = false)
    private Status status;

    @Size(max = 500)
    private String observacoes;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JoinColumn(name = "detalhes_id", unique = true)
    @JsonManagedReference
    private DetalhesEstadia detalhes;

    public Reserva(Long id, String nomeHospede, String emailHospede, LocalDate dataEntrada, LocalDate dataSaida, LocalDateTime dataCheckin, LocalDateTime dataCheckout, LocalDateTime dataCriacao, TipoQuarto tipoQuarto, Status status, String observacoes, DetalhesEstadia detalhes) {
        this.id = id;
        this.nomeHospede = nomeHospede;
        this.emailHospede = emailHospede;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.dataCheckin = dataCheckin;
        this.dataCheckout = dataCheckout;
        this.dataCriacao = dataCriacao;
        this.tipoQuarto = tipoQuarto;
        this.status = status;
        this.observacoes = observacoes;
        this.detalhes = detalhes;
    }

    public Reserva() {}

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getNomeHospede() {
        return nomeHospede;
    }

    public void setNomeHospede(String nomeHospede) {
        this.nomeHospede = nomeHospede;
    }

    public String getEmailHospede() {
        return emailHospede;
    }

    public void setEmailHospede(String emailHospede) {
        this.emailHospede = emailHospede;
    }

    public LocalDate getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(LocalDate dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public LocalDate getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(LocalDate dataSaida) {
        this.dataSaida = dataSaida;
    }

    public LocalDateTime getDataCheckin() {
        return dataCheckin;
    }

    public void setDataCheckin(LocalDateTime dataCheckin) {
        this.dataCheckin = dataCheckin;
    }

    public LocalDateTime getDataCheckout() {
        return dataCheckout;
    }

    public void setDataCheckout(LocalDateTime dataCheckout) {
        this.dataCheckout = dataCheckout;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public TipoQuarto getTipoQuarto() {
        return tipoQuarto;
    }

    public void setTipoQuarto(TipoQuarto tipoQuarto) {
        this.tipoQuarto = tipoQuarto;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public DetalhesEstadia getDetalhes() {
        return detalhes;
    }

    public void setDetalhes(DetalhesEstadia detalhes) {
        this.detalhes = detalhes;
    }
}
