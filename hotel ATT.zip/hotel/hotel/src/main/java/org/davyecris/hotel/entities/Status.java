package org.davyecris.hotel.entities;

public enum Status {
    PENDENTE,
    CONFIRMADA,
    EM_HOSPEDAGEM,
    CONCLUIDA,
    CANCELADA,
}