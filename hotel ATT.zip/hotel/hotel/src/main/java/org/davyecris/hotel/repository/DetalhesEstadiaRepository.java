package org.davyecris.hotel.repository;

import org.davyecris.hotel.entities.DetalhesEstadia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalhesEstadiaRepository extends JpaRepository<DetalhesEstadia, Long> {

}
