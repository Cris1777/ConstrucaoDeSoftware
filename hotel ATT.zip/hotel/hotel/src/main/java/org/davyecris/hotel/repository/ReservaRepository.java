package org.davyecris.hotel.repository;

import org.davyecris.hotel.entities.Reserva;
import org.davyecris.hotel.entities.Status;
import org.davyecris.hotel.entities.TipoQuarto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long>{

    List<Reserva> findAllByStatus(Status status);
    List<Reserva> findAllByTipoQuarto(TipoQuarto tipoQuarto);
    List<Reserva> findByNomeHospedeContainingIgnoreCase(String nomeHospede);
    List<Reserva> findByEmailHospedeContainingIgnoreCase(String emailHospede);
    List<Reserva> findByDataCheckinBetween(LocalDateTime inicio, LocalDateTime fim);

}
