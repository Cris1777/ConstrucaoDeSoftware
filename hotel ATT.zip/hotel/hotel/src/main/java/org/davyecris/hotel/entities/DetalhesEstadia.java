package org.davyecris.hotel.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity

public class DetalhesEstadia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String numeroQuarto;

    @NotNull
    @Min(1)
    private Integer andar;

    @Column(columnDefinition = "boolean default false")
    private Boolean possuiFrigobar;

    @Column(columnDefinition = "boolean default false")
    private Boolean possuiVaranda;

    @Column(columnDefinition = "boolean default false")
    private Boolean acessibilidade;

    @Size(max=300)
    private String observacaoQuarto;


    @OneToOne(mappedBy = "detalhes")
    @JsonBackReference
    private Reserva reserva;


    public DetalhesEstadia(Long id, String numeroQuarto, Integer andar, Boolean possuiFrigobar, Boolean possuiVaranda, String observacaoQuarto, Reserva reserva) {
        this.id = id;
        this.numeroQuarto = numeroQuarto;
        this.andar = andar;
        this.possuiFrigobar = possuiFrigobar;
        this.possuiVaranda = possuiVaranda;
        this.observacaoQuarto = observacaoQuarto;
        this.reserva = reserva;
    }

    public DetalhesEstadia() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getNumeroQuarto() {
        return numeroQuarto;
    }

    public void setNumeroQuarto(String numeroQuarto) {
        this.numeroQuarto = numeroQuarto;
    }

    public Integer getAndar() {
        return andar;
    }

    public void setAndar(Integer andar) {
        this.andar = andar;
    }

    public Boolean getPossuiFrigobar() {
        return possuiFrigobar;
    }

    public void setPossuiFrigobar(Boolean possuiFrigobar) {
        this.possuiFrigobar = possuiFrigobar;
    }

    public Boolean getPossuiVaranda() {
        return possuiVaranda;
    }

    public void setPossuiVaranda(Boolean possuiVaranda) {
        this.possuiVaranda = possuiVaranda;
    }

    public String getObservacaoQuarto() {
        return observacaoQuarto;
    }

    public void setObservacaoQuarto(String observacaoQuarto) {
        this.observacaoQuarto = observacaoQuarto;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }

    public Boolean getAcessibilidade() {
        return acessibilidade;
    }

    public void setAcessibilidade(Boolean acessibilidade) {
        this.acessibilidade = acessibilidade;
    }
}


