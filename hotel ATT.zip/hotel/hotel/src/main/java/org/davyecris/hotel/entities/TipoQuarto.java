package org.davyecris.hotel.entities;

public enum TipoQuarto {
    SOLTEIRO,
    DUPLO,
    SUITE,
    SUITE_PRESIDENCIAL
}
