package org.davyecris.hotel.service;

import org.davyecris.hotel.entities.DetalhesEstadia;
import org.davyecris.hotel.entities.Reserva;
import org.davyecris.hotel.entities.Status;
import org.davyecris.hotel.entities.TipoQuarto;
import org.davyecris.hotel.repository.ReservaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ReservaService {

    private final ReservaRepository reservaRepository;

    public ReservaService(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    public Reserva createReserva(Reserva reserva) {
        reserva.setId(null);
        reserva.setDataCriacao(LocalDateTime.now());
        reserva.setStatus(Status.PENDENTE);

        return reservaRepository.save(reserva);
    }

    public List<Reserva> findAll() {
        return reservaRepository.findAll();
    }

    public Optional<Reserva> findById(Long id) {
        return reservaRepository.findById(id);
    }

    public void delete(Long id) {
        Reserva r = buscar(id);

        if (r.getStatus() == Status.EM_HOSPEDAGEM) {
            throw new RuntimeException("Reserva em hospedagem não pode ser deletada");
        }

        reservaRepository.delete(r);
    }

    private Reserva buscar(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reserva não encontrada"));
    }

    // ===============================
    // DETALHES
    // ===============================

    public Reserva adicionarDetalhes(Long id, DetalhesEstadia detalhes) {
        Reserva reserva = buscar(id);

        if (reserva.getStatus() == Status.CANCELADA || reserva.getStatus() == Status.CONCLUIDA) {
            throw new RuntimeException("Não pode adicionar detalhes");
        }

        if (reserva.getDetalhes() != null) {
            throw new RuntimeException("Reserva já possui detalhes");
        }

        reserva.setDetalhes(detalhes);
        detalhes.setReserva(reserva);

        return reservaRepository.save(reserva);
    }

    public DetalhesEstadia buscarDetalhes(Long id) {
        Reserva reserva = buscar(id);

        if (reserva.getDetalhes() == null) {
            throw new RuntimeException("Detalhes não encontrados");
        }

        return reserva.getDetalhes();
    }

    public Reserva atualizarDetalhes(Long id, DetalhesEstadia detalhes) {
        Reserva reserva = buscar(id);

        if (reserva.getDetalhes() == null) {
            throw new RuntimeException("Detalhes inexistentes");
        }

        detalhes.setId(reserva.getDetalhes().getId());
        detalhes.setReserva(reserva);

        reserva.setDetalhes(detalhes);

        return reservaRepository.save(reserva);
    }

    public void removerDetalhes(Long id) {
        Reserva reserva = buscar(id);
        reserva.setDetalhes(null);
        reservaRepository.save(reserva);
    }

    // ===============================
    // STATUS
    // ===============================

    public void confirmarHospedagem(Long id) {
        Reserva r = buscar(id);

        if (r.getStatus() != Status.PENDENTE) {
            throw new RuntimeException("Só pode confirmar pendente");
        }

        r.setStatus(Status.CONFIRMADA);
    }

    public void emHospedagem(Long id) {
        Reserva r = buscar(id);

        if (r.getStatus() != Status.CONFIRMADA) {
            throw new RuntimeException("Só pode fazer check-in se confirmada");
        }

        if (LocalDate.now().isBefore(r.getDataEntrada())) {
            throw new RuntimeException("Check-in antes da data");
        }

        r.setStatus(Status.EM_HOSPEDAGEM);
        r.setDataCheckin(LocalDateTime.now());
    }

    public void concluirHospedagem(Long id) {
        Reserva r = buscar(id);

        if (r.getStatus() != Status.EM_HOSPEDAGEM) {
            throw new RuntimeException("Check-out inválido");
        }

        r.setStatus(Status.CONCLUIDA);
        r.setDataCheckout(LocalDateTime.now());
    }

    public void cancelar(Long id) {
        Reserva r = buscar(id);

        if (r.getStatus() == Status.CONCLUIDA) {
            throw new RuntimeException("Não pode cancelar concluída");
        }

        r.setStatus(Status.CANCELADA);
    }

    // ===============================
    // FILTROS
    // ===============================

    public List<Reserva> findByStatus(Status status) {
        return reservaRepository.findAllByStatus(status);
    }

    public List<Reserva> findByTipoQuarto(TipoQuarto tipo) {
        return reservaRepository.findAllByTipoQuarto(tipo);
    }

    public List<Reserva> buscarPorNomeOuEmail(String termo) {
        List<Reserva> nome = reservaRepository.findByNomeHospedeContainingIgnoreCase(termo);
        List<Reserva> email = reservaRepository.findByEmailHospedeContainingIgnoreCase(termo);

        nome.addAll(email);
        return nome;
    }

    public List<Reserva> reservasDeHoje() {
        return reservaRepository.findAll().stream()
                .filter(r -> r.getDataEntrada().equals(LocalDate.now()))
                .toList();
    }

    public List<Reserva> proximas(int dias) {
        LocalDate limite = LocalDate.now().plusDays(dias);

        return reservaRepository.findAll().stream()
                .filter(r -> !r.getDataEntrada().isBefore(LocalDate.now()) &&
                        !r.getDataEntrada().isAfter(limite))
                .toList();
    }
}