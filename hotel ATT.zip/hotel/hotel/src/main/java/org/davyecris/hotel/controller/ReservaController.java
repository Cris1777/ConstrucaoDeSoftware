package org.davyecris.hotel.controller;

import org.davyecris.hotel.entities.DetalhesEstadia;
import org.davyecris.hotel.entities.Reserva;
import org.davyecris.hotel.entities.Status;
import org.davyecris.hotel.entities.TipoQuarto;
import org.davyecris.hotel.service.ReservaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservas")
public class ReservaController {

    private final ReservaService reservaService;

    public ReservaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @PostMapping
    public ResponseEntity<Reserva> criar(@RequestBody Reserva reserva) {
        return ResponseEntity.ok(reservaService.createReserva(reserva));
    }

    @GetMapping
    public ResponseEntity<List<Reserva>> listar() {
        return ResponseEntity.ok(reservaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reserva> buscarPorId(@PathVariable Long id) {
        return reservaService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reserva> atualizar(@PathVariable Long id, @RequestBody Reserva reserva) {
        return reservaService.findById(id)
                .map(r -> {
                    reserva.setId(id);
                    return ResponseEntity.ok(reservaService.createReserva(reserva));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        return reservaService.findById(id)
                .map(r -> {
                    reservaService.delete(id);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Reserva>> buscarPorStatus(@PathVariable Status status) {
        return ResponseEntity.ok(reservaService.findByStatus(status));
    }

    @GetMapping("/tipo/{tipoQuarto}")
    public ResponseEntity<List<Reserva>> buscarPorTipo(@PathVariable TipoQuarto tipoQuarto) {
        return ResponseEntity.ok(reservaService.findByTipoQuarto(tipoQuarto));
    }

    @PostMapping("/{id}/detalhes")
    public ResponseEntity<Reserva> adicionarDetalhes(@PathVariable Long id, @RequestBody DetalhesEstadia detalhes) {
        return ResponseEntity.status(201).body(reservaService.adicionarDetalhes(id, detalhes));
    }

    @GetMapping("/{id}/detalhes")
    public ResponseEntity<DetalhesEstadia> buscarDetalhes(@PathVariable Long id) {
        return ResponseEntity.ok(reservaService.buscarDetalhes(id));
    }

    @PutMapping("/{id}/detalhes")
    public ResponseEntity<Reserva> atualizarDetalhes(@PathVariable Long id, @RequestBody DetalhesEstadia detalhes) {
        return ResponseEntity.ok(reservaService.atualizarDetalhes(id, detalhes));
    }

    @DeleteMapping("/{id}/detalhes")
    public ResponseEntity<Void> removerDetalhes(@PathVariable Long id) {
        reservaService.removerDetalhes(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<Void> cancelar(@PathVariable Long id) {
        reservaService.cancelar(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/hoje")
    public ResponseEntity<List<Reserva>> hoje() {
        return ResponseEntity.ok(reservaService.reservasDeHoje());
    }

    @GetMapping("/proximas")
    public ResponseEntity<List<Reserva>> proximas(@RequestParam Integer dias) {
        return ResponseEntity.ok(reservaService.proximas(dias));
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<Reserva>> buscar(@RequestParam String termo) {
        return ResponseEntity.ok(reservaService.buscarPorNomeOuEmail(termo));
    }

    @GetMapping("/em-hospedagem")
    public ResponseEntity<List<Reserva>> emHospedagem() {
        return ResponseEntity.ok(reservaService.findByStatus(Status.EM_HOSPEDAGEM));
    }

    @PutMapping("/{id}/confirmar")
    public ResponseEntity<Void> confirmar(@PathVariable Long id) {
        reservaService.confirmarHospedagem(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/checkin")
    public ResponseEntity<Void> checkin(@PathVariable Long id) {
        reservaService.emHospedagem(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/checkout")
    public ResponseEntity<Void> checkout(@PathVariable Long id) {
        reservaService.concluirHospedagem(id);
        return ResponseEntity.ok().build();
    }
}
